package com.zootopia.rpg.entity;

import java.util.EnumSet;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

/**
 * Leão base. O leão do bem protege os castelos (ataca monstros e leões malignos);
 * o leão maligno ataca jogadores que chegam perto, morde com animação e ruge empurrando.
 *
 * Valores em PONTOS de vida (2 pontos = 1 coração):
 * vida 40 = 20 corações, mordida maligna 16 = 8 corações, empurrão do rugido ~6 blocos.
 */
public abstract class AbstractLion extends PathfinderMob {
    public static final double MAX_HEALTH = 40.0D;
    public static final double EVIL_BITE = 16.0D;
    public static final double GOOD_BITE = 12.0D;
    /** Velocidade horizontal do rugido (~6 blocos de empurrão). */
    public static final double ROAR_PUSH = 1.0D;

    private static final byte EVENT_BITE = 71;
    private static final byte EVENT_ROAR = 72;

    /** Contadores só para a animação (rodam no cliente e no servidor). */
    public int biteAnim = 0;
    public int roarAnim = 0;

    private BlockPos home = null;
    private int homeRadius = 0;

    protected AbstractLion(EntityType<? extends AbstractLion> type, Level level) {
        super(type, level);
        this.xpReward = 20;
    }

    public abstract boolean isEvil();

    public static AttributeSupplier.Builder attributes(double bite) {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, MAX_HEALTH)
                .add(Attributes.MOVEMENT_SPEED, 0.3D)
                .add(Attributes.ATTACK_DAMAGE, bite)
                .add(Attributes.FOLLOW_RANGE, 32.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.6D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new RoarGoal(this));
        this.goalSelector.addGoal(2, new BiteGoal(this, 1.15D));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.7D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 10.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        if (isEvil()) {
            this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 10, true, false,
                    p -> this.distanceToSqr(p) < 18.0D * 18.0D));
            this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, AbstractLion.class, 10, true, false,
                    l -> l instanceof AbstractLion lion && !lion.isEvil()));
        } else {
            this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Monster.class, true));
            this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, AbstractLion.class, 10, true, false,
                    l -> l instanceof AbstractLion lion && lion.isEvil()));
        }
    }

    /** Define a "casa" do leão: ele passeia só perto dela (guarda de portão/porta). */
    public void setHome(BlockPos pos, int radius) {
        this.home = pos;
        this.homeRadius = radius;
        this.restrictTo(pos, radius);
    }

    public void bite(LivingEntity target) {
        this.level.broadcastEntityEvent(this, EVENT_BITE);
        this.playSound(SoundEvents.FOX_BITE, 1.3F, 0.6F);
        this.doHurtTarget(target);
    }

    public void roar() {
        this.level.broadcastEntityEvent(this, EVENT_ROAR);
        this.playSound(SoundEvents.RAVAGER_ROAR, 2.0F, 0.6F);
    }

    /** Empurra tudo que está perto, ~6 blocos para longe. */
    public void roarPush() {
        AABB area = this.getBoundingBox().inflate(8.0D);
        for (LivingEntity e : this.level.getEntitiesOfClass(LivingEntity.class, area,
                t -> t != this && !(t instanceof AbstractLion) && t.isAlive())) {
            double dx = e.getX() - this.getX();
            double dz = e.getZ() - this.getZ();
            double len = Math.sqrt(dx * dx + dz * dz);
            if (len < 0.01D) {
                dx = 1.0D;
                dz = 0.0D;
                len = 1.0D;
            }
            e.setDeltaMovement(dx / len * ROAR_PUSH, 0.35D, dz / len * ROAR_PUSH);
            e.hurtMarked = true;
        }
    }

    @Override
    public void handleEntityEvent(byte id) {
        if (id == EVENT_BITE) {
            this.biteAnim = 10;
        } else if (id == EVENT_ROAR) {
            this.roarAnim = 40;
        } else {
            super.handleEntityEvent(id);
        }
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.biteAnim > 0) this.biteAnim--;
        if (this.roarAnim > 0) this.roarAnim--;
    }

    @Override
    public boolean removeWhenFarAway(double dist) {
        return false;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource src) {
        return SoundEvents.RAVAGER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.RAVAGER_DEATH;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (home != null) {
            tag.putInt("HomeX", home.getX());
            tag.putInt("HomeY", home.getY());
            tag.putInt("HomeZ", home.getZ());
            tag.putInt("HomeR", homeRadius);
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("HomeR")) {
            setHome(new BlockPos(tag.getInt("HomeX"), tag.getInt("HomeY"), tag.getInt("HomeZ")), tag.getInt("HomeR"));
        }
    }

    /** Ataque corpo a corpo com animação de mordida. */
    static class BiteGoal extends MeleeAttackGoal {
        private final AbstractLion lion;

        BiteGoal(AbstractLion lion, double speed) {
            super(lion, speed, true);
            this.lion = lion;
        }

        @Override
        protected void checkAndPerformAttack(LivingEntity target, double distSqr) {
            if (distSqr <= this.getAttackReachSqr(target) && this.isTimeToAttack()) {
                this.resetAttackCooldown();
                lion.bite(target);
            }
        }
    }

    /** Só o leão maligno ruge: para, olha para o alvo e empurra todo mundo ~6 blocos. */
    static class RoarGoal extends Goal {
        private final AbstractLion lion;
        private int timer;
        private int cooldown = 60;

        RoarGoal(AbstractLion lion) {
            this.lion = lion;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.JUMP));
        }

        @Override
        public boolean canUse() {
            if (!lion.isEvil()) return false;
            if (cooldown > 0) {
                cooldown--;
                return false;
            }
            LivingEntity t = lion.getTarget();
            return t != null && t.isAlive() && lion.distanceToSqr(t) < 49.0D;
        }

        @Override
        public boolean canContinueToUse() {
            return timer > 0;
        }

        @Override
        public void start() {
            timer = 40;
            lion.getNavigation().stop();
            lion.roar();
        }

        @Override
        public void tick() {
            timer--;
            if (timer == 26) lion.roarPush();
            LivingEntity t = lion.getTarget();
            if (t != null) lion.getLookControl().setLookAt(t, 30.0F, 30.0F);
        }

        @Override
        public void stop() {
            cooldown = 160 + lion.getRandom().nextInt(80);
        }
    }
}
