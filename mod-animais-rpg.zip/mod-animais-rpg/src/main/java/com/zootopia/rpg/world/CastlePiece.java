package com.zootopia.rpg.world;

import com.zootopia.rpg.ModEntities;
import com.zootopia.rpg.ModStructures;
import com.zootopia.rpg.entity.AbstractLion;
import java.util.Random;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.StructureFeatureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.IronBarsBlock;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import net.minecraft.world.level.levelgen.structure.StructurePieceType;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceSerializationContext;

/**
 * Castelo gerado por código (sem arquivos .nbt).
 * Coordenadas locais: x,z de 0 até tamanho-1; y=0 é o piso (nível do chão), y negativo é a fundação.
 */
public class CastlePiece extends StructurePiece {
    public static final int GOOD_SIZE = 41;
    public static final int EVIL_SIZE = 37;

    private final boolean evil;

    private static final BlockState AIR = Blocks.AIR.defaultBlockState();
    private static final BlockState STONE = Blocks.STONE_BRICKS.defaultBlockState();
    private static final BlockState BLACK = Blocks.BLACKSTONE.defaultBlockState();
    private static final BlockState POL = Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState();
    private static final BlockState CRACKED = Blocks.CRACKED_POLISHED_BLACKSTONE_BRICKS.defaultBlockState();
    private static final BlockState DEEP = Blocks.DEEPSLATE_BRICKS.defaultBlockState();
    private static final BlockState TILES = Blocks.DEEPSLATE_TILES.defaultBlockState();
    private static final BlockState PLANKS = Blocks.DARK_OAK_PLANKS.defaultBlockState();
    private static final BlockState GLASS = Blocks.BLACK_STAINED_GLASS.defaultBlockState();
    private static final BlockState RED_GLASS = Blocks.RED_STAINED_GLASS.defaultBlockState();
    private static final BlockState LANTERN = Blocks.LANTERN.defaultBlockState();
    private static final BlockState SOUL_LANTERN = Blocks.SOUL_LANTERN.defaultBlockState();
    private static final BlockState CRYING = Blocks.CRYING_OBSIDIAN.defaultBlockState();

    public CastlePiece(StructurePieceType type, BoundingBox bb, boolean evil) {
        super(type, 0, bb);
        this.evil = evil;
        this.setOrientation(Direction.NORTH);
    }

    public CastlePiece(StructurePieceSerializationContext ctx, CompoundTag tag) {
        super(ModStructures.CASTLE_PIECE, tag);
        this.evil = tag.getBoolean("Evil");
        this.setOrientation(Direction.NORTH);
    }

    @Override
    protected void addAdditionalSaveData(StructurePieceSerializationContext ctx, CompoundTag tag) {
        tag.putBoolean("Evil", evil);
    }

    // ------------------------------------------------------------------ helpers

    private void set(WorldGenLevel lv, BoundingBox bb, BlockState s, int x, int y, int z) {
        placeBlock(lv, s, x, y, z, bb);
    }

    private void fill(WorldGenLevel lv, BoundingBox bb, BlockState s, int x1, int y1, int z1, int x2, int y2, int z2) {
        for (int y = y1; y <= y2; y++) {
            for (int x = x1; x <= x2; x++) {
                for (int z = z1; z <= z2; z++) {
                    placeBlock(lv, s, x, y, z, bb);
                }
            }
        }
    }

    /** Só o contorno (anel) de um retângulo, numa altura. */
    private void ring(WorldGenLevel lv, BoundingBox bb, BlockState s, int x1, int z1, int x2, int z2, int y) {
        for (int x = x1; x <= x2; x++) {
            set(lv, bb, s, x, y, z1);
            set(lv, bb, s, x, y, z2);
        }
        for (int z = z1; z <= z2; z++) {
            set(lv, bb, s, x1, y, z);
            set(lv, bb, s, x2, y, z);
        }
    }

    /** Ameias: anel com blocos alternados. */
    private void merlons(WorldGenLevel lv, BoundingBox bb, BlockState s, int x1, int z1, int x2, int z2, int y) {
        for (int x = x1; x <= x2; x += 2) {
            set(lv, bb, s, x, y, z1);
            set(lv, bb, s, x, y, z2);
        }
        for (int z = z1; z <= z2; z += 2) {
            set(lv, bb, s, x1, y, z);
            set(lv, bb, s, x2, y, z);
        }
    }

    private void door(WorldGenLevel lv, BoundingBox bb, Direction facing, int x, int y, int z) {
        BlockState d = Blocks.DARK_OAK_DOOR.defaultBlockState().setValue(DoorBlock.FACING, facing);
        set(lv, bb, d.setValue(DoorBlock.HALF, DoubleBlockHalf.LOWER), x, y, z);
        set(lv, bb, d.setValue(DoorBlock.HALF, DoubleBlockHalf.UPPER), x, y + 1, z);
    }

    /** Cama com os pés em z e a cabeceira em z+1 (local), virada para NORTE no mundo. */
    private void bed(WorldGenLevel lv, BoundingBox bb, Block bed, int x, int y, int z) {
        BlockState b = bed.defaultBlockState().setValue(BedBlock.FACING, Direction.NORTH);
        set(lv, bb, b.setValue(BedBlock.PART, BedPart.FOOT), x, y, z);
        set(lv, bb, b.setValue(BedBlock.PART, BedPart.HEAD), x, y, z + 1);
    }

    private void ladderEast(WorldGenLevel lv, BoundingBox bb, int x, int y1, int y2, int z) {
        BlockState l = Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING, Direction.EAST);
        for (int y = y1; y <= y2; y++) set(lv, bb, l, x, y, z);
    }

    private BlockState hanging(BlockState lantern) {
        return lantern.setValue(LanternBlock.HANGING, true);
    }

    /** Poste de luz: pilar com lanterna em cima. */
    private void lampPost(WorldGenLevel lv, BoundingBox bb, BlockState lantern, int x, int z, int h) {
        fill(lv, bb, POL, x, 1, z, x, h, z);
        set(lv, bb, lantern, x, h + 1, z);
    }

    private void lion(WorldGenLevel lv, BoundingBox bb, Random r, boolean evilLion, int x, int y, int z, int radius) {
        BlockPos wp = new BlockPos(getWorldX(x, z), getWorldY(y), getWorldZ(x, z));
        if (!bb.isInside(wp)) return;
        EntityType<? extends AbstractLion> t = evilLion ? ModEntities.EVIL_LION.get() : ModEntities.GOOD_LION.get();
        ServerLevel sl = lv.getLevel();
        AbstractLion l = t.create(sl);
        if (l == null) return;
        l.moveTo(wp.getX() + 0.5D, wp.getY(), wp.getZ() + 0.5D, r.nextFloat() * 360.0F, 0.0F);
        l.setHome(wp, radius);
        l.setPersistenceRequired();
        l.finalizeSpawn(lv, lv.getCurrentDifficultyAt(wp), MobSpawnType.STRUCTURE, null, null);
        lv.addFreshEntityWithPassengers(l);
    }

    // ------------------------------------------------------------------ entrada

    @Override
    public void postProcess(WorldGenLevel lv, StructureFeatureManager sfm, ChunkGenerator gen, Random r,
                            BoundingBox bb, ChunkPos cp, BlockPos pivot) {
        if (evil) buildEvil(lv, r, bb); else buildGood(lv, r, bb);
    }

    // ------------------------------------------------------------------ castelo preto e cinza (do bem)

    private void goodTower(WorldGenLevel lv, BoundingBox bb, int ox, int oz) {
        // corpo
        fill(lv, bb, STONE, ox, 1, oz, ox + 8, 16, oz + 8);
        fill(lv, bb, BLACK, ox, 1, oz, ox + 8, 2, oz + 8);
        fill(lv, bb, AIR, ox + 1, 1, oz + 1, ox + 7, 16, oz + 7);
        ring(lv, bb, POL, ox, oz, ox + 8, oz + 8, 8);
        ring(lv, bb, POL, ox, oz, ox + 8, oz + 8, 16);
        // cantos reforçados
        for (int cx : new int[]{ox, ox + 8}) {
            for (int cz : new int[]{oz, oz + 8}) {
                fill(lv, bb, BLACK, cx, 3, cz, cx, 15, cz);
            }
        }
        // piso do andar de cima (alinhado com o caminho da muralha)
        fill(lv, bb, PLANKS, ox + 1, 8, oz + 1, ox + 7, 8, oz + 7);
        // janelas
        for (int y : new int[]{4, 12}) {
            set(lv, bb, GLASS, ox + 4, y, oz);
            set(lv, bb, GLASS, ox + 4, y, oz + 8);
            set(lv, bb, GLASS, ox, y, oz + 4);
            set(lv, bb, GLASS, ox + 8, y, oz + 4);
        }
        // telhado em pirâmide
        for (int k = 0; k < 5; k++) {
            int s = 9 - 2 * k;
            fill(lv, bb, k % 2 == 0 ? TILES : DEEP, ox + k, 17 + k, oz + k, ox + k + s - 1, 17 + k, oz + k + s - 1);
        }
        set(lv, bb, Blocks.LIGHTNING_ROD.defaultBlockState(), ox + 4, 22, oz + 4);
        // lanternas no teto de cada andar
        set(lv, bb, hanging(LANTERN), ox + 4, 7, oz + 4);
        set(lv, bb, hanging(LANTERN), ox + 4, 16, oz + 4);

        // porta para o pátio
        boolean west = ox == 0;
        boolean south = oz == 0;
        int dx = west ? ox + 8 : ox;
        int dz = south ? 6 : 34;
        fill(lv, bb, AIR, dx, 1, dz, dx, 2, dz);
        door(lv, bb, west ? Direction.EAST : Direction.WEST, dx, 1, dz);
        // passagens do caminho da muralha para dentro da torre
        int wallZ1 = south ? 2 : 36;
        int wallX1 = west ? 2 : 36;
        fill(lv, bb, AIR, dx, 9, wallZ1, dx, 10, wallZ1 + 2);
        int dz2 = south ? oz + 8 : oz;
        fill(lv, bb, AIR, wallX1, 9, dz2, wallX1 + 2, 10, dz2);
    }

    private void buildGood(WorldGenLevel lv, Random r, BoundingBox bb) {
        // --- limpar, fundação e piso do pátio
        fill(lv, bb, AIR, 0, 0, 0, 40, 36, 40);
        for (int x = 0; x <= 40; x++) {
            for (int z = 0; z <= 40; z++) {
                fillColumnDown(lv, STONE, x, -1, z, bb);
                set(lv, bb, (x + z) % 7 == 0 && r.nextInt(3) == 0 ? POL : STONE, x, 0, z);
            }
        }
        // caminho preto do portão até o castelo
        fill(lv, bb, POL, 18, 0, 0, 22, 0, 14);

        // --- muralha externa (3 de espessura)
        fill(lv, bb, STONE, 2, 1, 2, 38, 8, 4);
        fill(lv, bb, STONE, 2, 1, 36, 38, 8, 38);
        fill(lv, bb, STONE, 2, 1, 2, 4, 8, 38);
        fill(lv, bb, STONE, 36, 1, 2, 38, 8, 38);
        fill(lv, bb, BLACK, 2, 1, 2, 38, 2, 4);
        fill(lv, bb, BLACK, 2, 1, 36, 38, 2, 38);
        fill(lv, bb, BLACK, 2, 1, 2, 4, 2, 38);
        fill(lv, bb, BLACK, 36, 1, 2, 38, 2, 38);
        // faixa escura no alto
        ring(lv, bb, POL, 2, 2, 38, 38, 7);
        // parapeito + ameias (borda de fora e de dentro)
        ring(lv, bb, STONE, 2, 2, 38, 38, 9);
        merlons(lv, bb, STONE, 2, 2, 38, 38, 10);
        merlons(lv, bb, STONE, 4, 4, 36, 36, 9);

        // --- torres de canto
        goodTower(lv, bb, 0, 0);
        goodTower(lv, bb, 32, 0);
        goodTower(lv, bb, 0, 32);
        goodTower(lv, bb, 32, 32);

        // --- portão principal (lado z baixo)
        fill(lv, bb, AIR, 18, 1, 2, 22, 5, 4);
        fill(lv, bb, AIR, 19, 6, 2, 21, 6, 4);
        for (int z = 2; z <= 4; z++) {
            set(lv, bb, POL, 18, 6, z);
            set(lv, bb, POL, 22, 6, z);
        }
        // grade levantada e lanternas
        BlockState bars = Blocks.IRON_BARS.defaultBlockState().setValue(IronBarsBlock.EAST, true).setValue(IronBarsBlock.WEST, true);
        for (int x = 18; x <= 22; x++) set(lv, bb, bars, x, 5, 3);
        set(lv, bb, hanging(LANTERN), 20, 4, 3);
        // pilares do portão
        for (int px : new int[]{15, 23}) {
            fill(lv, bb, STONE, px, 1, 1, px + 2, 13, 5);
            fill(lv, bb, BLACK, px, 1, 1, px + 2, 2, 5);
            ring(lv, bb, POL, px, 1, px + 2, 5, 7);
            ring(lv, bb, POL, px, 1, px + 2, 5, 13);
            merlons(lv, bb, STONE, px, 1, px + 2, 5, 14);
            set(lv, bb, LANTERN, px + 1, 14, 3);
        }
        // faixa de entrada
        fill(lv, bb, AIR, 18, 1, 5, 22, 6, 5);

        // --- castelo principal (keep)
        fill(lv, bb, STONE, 13, 1, 15, 27, 13, 29);
        fill(lv, bb, AIR, 14, 1, 16, 26, 13, 28);
        fill(lv, bb, STONE, 13, 14, 15, 27, 14, 29);
        for (int cx : new int[]{13, 27}) {
            for (int cz : new int[]{15, 29}) fill(lv, bb, BLACK, cx, 1, cz, cx, 14, cz);
        }
        fill(lv, bb, BLACK, 13, 1, 15, 27, 2, 29);
        fill(lv, bb, AIR, 14, 1, 16, 26, 2, 28);
        ring(lv, bb, POL, 13, 15, 27, 29, 7);
        ring(lv, bb, POL, 13, 15, 27, 29, 14);
        ring(lv, bb, STONE, 13, 15, 27, 29, 15);
        merlons(lv, bb, STONE, 13, 15, 27, 29, 16);
        // torrinhas no telhado
        for (int tx : new int[]{13, 25}) {
            for (int tz : new int[]{15, 27}) {
                fill(lv, bb, DEEP, tx, 15, tz, tx + 2, 19, tz + 2);
                fill(lv, bb, TILES, tx, 20, tz, tx + 2, 20, tz + 2);
                set(lv, bb, Blocks.LIGHTNING_ROD.defaultBlockState(), tx + 1, 21, tz + 1);
            }
        }
        // piso interno e segundo andar
        fill(lv, bb, PLANKS, 14, 0, 16, 26, 0, 28);
        fill(lv, bb, PLANKS, 14, 7, 16, 26, 7, 28);
        fill(lv, bb, AIR, 14, 7, 17, 14, 7, 17);
        ladderEast(lv, bb, 14, 1, 8, 17);
        // portas (frente e fundos)
        fill(lv, bb, AIR, 20, 1, 15, 20, 2, 15);
        door(lv, bb, Direction.NORTH, 20, 1, 15);
        fill(lv, bb, AIR, 20, 1, 29, 20, 2, 29);
        door(lv, bb, Direction.NORTH, 20, 1, 29);
        // janelas
        for (int y : new int[]{3, 10}) {
            for (int a : new int[]{17, 23}) {
                set(lv, bb, GLASS, a, y, 15);
                set(lv, bb, GLASS, a, y, 29);
            }
            for (int a : new int[]{19, 25}) {
                set(lv, bb, GLASS, 13, y, a);
                set(lv, bb, GLASS, 27, y, a);
            }
        }
        // salão: tapete, mesa, luminárias, estantes, baús
        fill(lv, bb, Blocks.RED_CARPET.defaultBlockState(), 20, 1, 16, 20, 1, 28);
        fill(lv, bb, Blocks.POLISHED_BLACKSTONE_BRICK_SLAB.defaultBlockState(), 17, 1, 22, 19, 1, 22);
        fill(lv, bb, Blocks.POLISHED_BLACKSTONE_BRICK_SLAB.defaultBlockState(), 21, 1, 22, 23, 1, 22);
        set(lv, bb, LANTERN, 18, 2, 22);
        set(lv, bb, LANTERN, 22, 2, 22);
        for (int px : new int[]{16, 24}) {
            for (int pz : new int[]{19, 25}) lampPost(lv, bb, LANTERN, px, pz, 3);
        }
        fill(lv, bb, Blocks.BOOKSHELF.defaultBlockState(), 15, 1, 28, 18, 3, 28);
        fill(lv, bb, Blocks.BOOKSHELF.defaultBlockState(), 22, 1, 28, 25, 3, 28);
        set(lv, bb, Blocks.CHEST.defaultBlockState(), 15, 1, 17);
        set(lv, bb, Blocks.CHEST.defaultBlockState(), 25, 1, 17);
        set(lv, bb, hanging(LANTERN), 20, 6, 20);
        set(lv, bb, hanging(LANTERN), 20, 6, 25);
        // segundo andar: quartos
        Block[] beds = {Blocks.RED_BED, Blocks.BLUE_BED, Blocks.GREEN_BED, Blocks.ORANGE_BED};
        int[] bx = {16, 19, 22, 25};
        for (int i = 0; i < 4; i++) bed(lv, bb, beds[i], bx[i], 8, 26);
        set(lv, bb, Blocks.CHEST.defaultBlockState(), 15, 8, 18);
        set(lv, bb, Blocks.CHEST.defaultBlockState(), 25, 8, 18);
        set(lv, bb, Blocks.BOOKSHELF.defaultBlockState(), 20, 8, 28);
        set(lv, bb, Blocks.BOOKSHELF.defaultBlockState(), 21, 8, 28);
        set(lv, bb, hanging(LANTERN), 18, 13, 20);
        set(lv, bb, hanging(LANTERN), 22, 13, 20);
        set(lv, bb, hanging(LANTERN), 20, 13, 25);

        // --- pátio: caminho, fonte, postes e jardins
        fill(lv, bb, POL, 19, 1, 9, 21, 1, 11);
        set(lv, bb, Blocks.WATER.defaultBlockState(), 20, 1, 10);
        set(lv, bb, Blocks.WATER.defaultBlockState(), 20, 0, 10);
        for (int pz : new int[]{6, 13}) {
            lampPost(lv, bb, LANTERN, 17, pz, 3);
            lampPost(lv, bb, LANTERN, 23, pz, 3);
        }
        Block[] flowers = {Blocks.DANDELION, Blocks.POPPY, Blocks.CORNFLOWER, Blocks.AZURE_BLUET};
        BlockState leaves = Blocks.OAK_LEAVES.defaultBlockState().setValue(LeavesBlock.PERSISTENT, true);
        for (int gx : new int[]{6, 29}) {
            fill(lv, bb, Blocks.GRASS_BLOCK.defaultBlockState(), gx, 0, 12, gx + 5, 0, 28);
            for (int x = gx; x <= gx + 5; x++) {
                for (int z = 12; z <= 28; z++) {
                    if (r.nextInt(4) == 0) set(lv, bb, flowers[r.nextInt(flowers.length)].defaultBlockState(), x, 1, z);
                }
            }
            for (int z : new int[]{14, 20, 26}) {
                set(lv, bb, leaves, gx + (gx < 20 ? 0 : 5), 1, z);
                set(lv, bb, leaves, gx + (gx < 20 ? 0 : 5), 2, z);
            }
        }

        // --- leões do bem: portão, portas do castelo e das torres
        lion(lv, bb, r, false, 19, 1, 7, 3);
        lion(lv, bb, r, false, 21, 1, 7, 3);
        lion(lv, bb, r, false, 18, 1, 13, 2);
        lion(lv, bb, r, false, 22, 1, 13, 2);
        lion(lv, bb, r, false, 20, 1, 31, 2);
        lion(lv, bb, r, false, 11, 1, 6, 2);
        lion(lv, bb, r, false, 29, 1, 6, 2);
        lion(lv, bb, r, false, 11, 1, 34, 2);
        lion(lv, bb, r, false, 29, 1, 34, 2);
    }

    // ------------------------------------------------------------------ castelo sombrio (do mal)

    private void evilTower(WorldGenLevel lv, BoundingBox bb, Random r, int ox, int oz, int h) {
        fill(lv, bb, BLACK, ox, 1, oz, ox + 6, h, oz + 6);
        fill(lv, bb, AIR, ox + 1, 1, oz + 1, ox + 5, h, oz + 5);
        for (int y = 3; y <= h; y += 4) ring(lv, bb, POL, ox, oz, ox + 6, oz + 6, y);
        ring(lv, bb, CRYING, ox, oz, ox + 6, oz + 6, h);
        // olhos vermelhos
        for (int y = h - 3; y <= h - 2; y++) {
            set(lv, bb, RED_GLASS, ox + 3, y, oz);
            set(lv, bb, RED_GLASS, ox + 3, y, oz + 6);
            set(lv, bb, RED_GLASS, ox, y, oz + 3);
            set(lv, bb, RED_GLASS, ox + 6, y, oz + 3);
        }
        // telhado pontudo + agulha
        fill(lv, bb, BLACK, ox, h + 1, oz, ox + 6, h + 1, oz + 6);
        fill(lv, bb, POL, ox + 1, h + 2, oz + 1, ox + 5, h + 2, oz + 5);
        fill(lv, bb, BLACK, ox + 2, h + 3, oz + 2, ox + 4, h + 3, oz + 4);
        fill(lv, bb, POL, ox + 3, h + 4, oz + 3, ox + 3, h + 7, oz + 3);
        set(lv, bb, CRYING, ox + 3, h + 8, oz + 3);
        set(lv, bb, hanging(SOUL_LANTERN), ox + 3, h, oz + 3);
        // porta para o pátio
        boolean west = ox == 0;
        boolean south = oz == 0;
        int dx = west ? ox + 6 : ox;
        int dz = south ? 4 : 32;
        fill(lv, bb, AIR, dx, 1, dz, dx, 2, dz);
        door(lv, bb, west ? Direction.EAST : Direction.WEST, dx, 1, dz);
    }

    private void buildEvil(WorldGenLevel lv, Random r, BoundingBox bb) {
        // --- limpar, fundação e piso corrompido
        fill(lv, bb, AIR, 0, 0, 0, 36, 40, 36);
        for (int x = 0; x <= 36; x++) {
            for (int z = 0; z <= 36; z++) {
                fillColumnDown(lv, BLACK, x, -1, z, bb);
                int p = r.nextInt(20);
                set(lv, bb, p == 0 ? CRYING : (p < 4 ? CRACKED : BLACK), x, 0, z);
            }
        }
        // caminho até a entrada
        for (int x = 16; x <= 20; x++) {
            for (int z = 0; z <= 11; z++) set(lv, bb, r.nextInt(6) == 0 ? CRACKED : POL, x, 0, z);
        }

        // --- muralha irregular com dentes
        for (int x = 2; x <= 34; x++) {
            for (int z = 2; z <= 34; z++) {
                boolean onRing = x <= 3 || x >= 33 || z <= 3 || z >= 33;
                if (!onRing) continue;
                int top = 6 + Math.abs((x * 13 + z * 7) % 4);
                for (int y = 1; y <= top; y++) {
                    set(lv, bb, r.nextInt(7) == 0 ? CRACKED : POL, x, y, z);
                }
            }
        }
        // entrada em forma de boca, com presas
        fill(lv, bb, AIR, 16, 1, 2, 20, 6, 3);
        for (int x : new int[]{16, 18, 20}) set(lv, bb, POL, x, 6, 2);
        for (int x : new int[]{17, 19}) set(lv, bb, POL, x, 1, 2);
        set(lv, bb, RED_GLASS, 15, 9, 2);
        set(lv, bb, RED_GLASS, 21, 9, 2);
        set(lv, bb, Blocks.SHROOMLIGHT.defaultBlockState(), 15, 9, 3);
        set(lv, bb, Blocks.SHROOMLIGHT.defaultBlockState(), 21, 9, 3);
        set(lv, bb, hanging(SOUL_LANTERN), 18, 5, 2);

        // --- torres tortas, cada uma de um tamanho
        evilTower(lv, bb, r, 0, 0, 14);
        evilTower(lv, bb, r, 30, 0, 20);
        evilTower(lv, bb, r, 0, 30, 17);
        evilTower(lv, bb, r, 30, 30, 24);

        // --- fortaleza central com espiral alta
        fill(lv, bb, BLACK, 12, 1, 12, 24, 16, 24);
        fill(lv, bb, AIR, 13, 1, 13, 23, 16, 23);
        for (int y = 4; y <= 16; y += 4) ring(lv, bb, CRYING, 12, 12, 24, 24, y);
        fill(lv, bb, BLACK, 12, 17, 12, 24, 17, 24);
        fill(lv, bb, POL, 15, 17, 15, 21, 28, 21);
        fill(lv, bb, AIR, 16, 17, 16, 20, 28, 20);
        fill(lv, bb, BLACK, 15, 29, 15, 21, 29, 21);
        fill(lv, bb, POL, 16, 30, 16, 20, 30, 20);
        fill(lv, bb, BLACK, 17, 31, 17, 19, 31, 19);
        fill(lv, bb, POL, 18, 32, 18, 18, 36, 18);
        set(lv, bb, CRYING, 18, 37, 18);
        // olhos gigantes na espiral
        for (int y = 23; y <= 24; y++) {
            set(lv, bb, RED_GLASS, 16, y, 15);
            set(lv, bb, RED_GLASS, 17, y, 15);
            set(lv, bb, RED_GLASS, 19, y, 15);
            set(lv, bb, RED_GLASS, 20, y, 15);
        }
        // espinhos nos cantos
        for (int cx : new int[]{12, 24}) {
            for (int cz : new int[]{12, 24}) {
                fill(lv, bb, BLACK, cx, 18, cz, cx, 21, cz);
                set(lv, bb, CRYING, cx, 22, cz);
            }
        }
        // entrada do salão
        fill(lv, bb, AIR, 17, 1, 12, 19, 3, 12);
        set(lv, bb, POL, 17, 3, 12);
        set(lv, bb, POL, 19, 3, 12);
        // sacada interna (andar 2) e escada
        fill(lv, bb, POL, 13, 8, 13, 15, 8, 23);
        fill(lv, bb, POL, 21, 8, 13, 23, 8, 23);
        fill(lv, bb, POL, 16, 8, 13, 20, 8, 15);
        fill(lv, bb, POL, 16, 8, 21, 20, 8, 23);
        fill(lv, bb, AIR, 13, 8, 18, 13, 8, 18);
        ladderEast(lv, bb, 13, 1, 9, 18);
        // trono
        fill(lv, bb, CRYING, 16, 1, 21, 20, 1, 23);
        fill(lv, bb, OBSIDIAN(), 17, 2, 23, 19, 5, 23);
        set(lv, bb, Blocks.SKELETON_SKULL.defaultBlockState(), 16, 2, 22);
        set(lv, bb, Blocks.SKELETON_SKULL.defaultBlockState(), 20, 2, 22);
        // fogueiras de alma, lanternas e teias
        for (int[] c : new int[][]{{14, 14}, {22, 14}, {14, 22}, {22, 22}, {15, 6}, {21, 6}, {15, 10}, {21, 10}}) {
            set(lv, bb, Blocks.SOUL_CAMPFIRE.defaultBlockState(), c[0], 1, c[1]);
        }
        set(lv, bb, hanging(SOUL_LANTERN), 18, 16, 18);
        set(lv, bb, hanging(SOUL_LANTERN), 14, 7, 20);
        set(lv, bb, hanging(SOUL_LANTERN), 22, 7, 20);
        for (int i = 0; i < 26; i++) {
            int x = 13 + r.nextInt(11);
            int z = 13 + r.nextInt(11);
            boolean edge = x == 13 || x == 23 || z == 13 || z == 23;
            if (edge) set(lv, bb, Blocks.COBWEB.defaultBlockState(), x, 10 + r.nextInt(6), z);
        }
        // pilares de ossos no pátio
        for (int[] c : new int[][]{{7, 8}, {29, 8}, {7, 20}, {29, 20}, {8, 28}, {28, 28}}) {
            int top = 4 + r.nextInt(3);
            fill(lv, bb, POL, c[0], 1, c[1], c[0], top, c[1]);
            set(lv, bb, Blocks.SKELETON_SKULL.defaultBlockState(), c[0], top + 1, c[1]);
        }

        // --- leões malignos
        lion(lv, bb, r, true, 14, 1, 1, 4);
        lion(lv, bb, r, true, 22, 1, 1, 4);
        lion(lv, bb, r, true, 10, 1, 9, 5);
        lion(lv, bb, r, true, 26, 1, 9, 5);
        lion(lv, bb, r, true, 16, 1, 16, 5);
        lion(lv, bb, r, true, 20, 1, 19, 5);
    }

    private static BlockState OBSIDIAN() {
        return Blocks.OBSIDIAN.defaultBlockState();
    }
}
