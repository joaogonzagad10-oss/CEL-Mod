package com.zootopia.rpg.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.zootopia.rpg.common.Race;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiComponent;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.TranslatableComponent;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ItemStack;

/**
 * HUD estilo RPG: barras de vida/fome/armadura/ar/XP com moldura dourada,
 * hotbar com slots entalhados, ícone da habilidade (tecla J) e arranhão de garra na tela.
 * Tudo é desenhado com retângulos, sem texturas extras.
 */
public final class RpgHud {
    private static final int GOLD = 0xFFB8892B;
    private static final int GOLD_LIGHT = 0xFFFFD36B;
    private static final int DARK = 0xFF0E0906;
    private static final int PANEL = 0xEE241A12;

    private RpgHud() {}

    private static void fill(PoseStack ps, int x1, int y1, int x2, int y2, int c) {
        GuiComponent.fill(ps, x1, y1, x2, y2, c);
    }

    private static int lerpColor(int a, int b, float t) {
        int aa = (a >>> 24) & 255, ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int ba = (b >>> 24) & 255, br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return ((int) Mth.lerp(t, aa, ba) << 24) | ((int) Mth.lerp(t, ar, br) << 16)
                | ((int) Mth.lerp(t, ag, bg) << 8) | (int) Mth.lerp(t, ab, bb);
    }

    private static void vgrad(PoseStack ps, int x1, int y1, int x2, int y2, int top, int bottom) {
        int h = y2 - y1;
        for (int i = 0; i < h; i++) {
            float t = h <= 1 ? 0.0F : (float) i / (h - 1);
            fill(ps, x1, y1 + i, x2, y1 + i + 1, lerpColor(top, bottom, t));
        }
    }

    private static void frame(PoseStack ps, int x1, int y1, int x2, int y2) {
        fill(ps, x1, y1, x2, y2, DARK);
        fill(ps, x1 + 1, y1 + 1, x2 - 1, y2 - 1, GOLD);
        fill(ps, x1 + 2, y1 + 2, x2 - 2, y2 - 2, PANEL);
        fill(ps, x1, y1, x1 + 2, y1 + 2, GOLD_LIGHT);
        fill(ps, x2 - 2, y1, x2, y1 + 2, GOLD_LIGHT);
        fill(ps, x1, y2 - 2, x1 + 2, y2, GOLD_LIGHT);
        fill(ps, x2 - 2, y2 - 2, x2, y2, GOLD_LIGHT);
    }

    /** Barra horizontal com fundo, preenchimento em degradê e brilho no topo. */
    private static void bar(PoseStack ps, int x, int y, int w, int h, float frac, int top, int bottom, int back) {
        fill(ps, x - 1, y - 1, x + w + 1, y + h + 1, DARK);
        fill(ps, x, y, x + w, y + h, back);
        int fw = Mth.clamp((int) (w * frac), 0, w);
        if (fw > 0) {
            vgrad(ps, x, y, x + fw, y + h, top, bottom);
            if (h >= 5) fill(ps, x, y, x + fw, y + 1, 0x55FFFFFF);
        }
    }

    public static void render(PoseStack ps, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null) return;
        Font font = mc.font;
        int cx = w / 2;
        int x0 = cx - 92;
        int y0 = h - 25;

        // ---- hotbar ----
        frame(ps, x0, y0, x0 + 184, y0 + 24);
        int sel = p.getInventory().selected;
        for (int i = 0; i < 9; i++) {
            int sx = x0 + 2 + i * 20;
            int sy = y0 + 2;
            fill(ps, sx, sy, sx + 20, sy + 20, i == sel ? GOLD_LIGHT : 0xFF3A2A1A);
            fill(ps, sx + 1, sy + 1, sx + 19, sy + 19, 0xFF0B0805);
            fill(ps, sx + 1, sy + 1, sx + 19, sy + 2, 0xFF000000);
            fill(ps, sx + 1, sy + 18, sx + 19, sy + 19, 0xFF2A1E12);
            if (i == sel) fill(ps, sx + 2, sy + 2, sx + 18, sy + 18, 0x33FFD36B);
        }
        for (int i = 0; i < 9; i++) {
            ItemStack st = p.getInventory().items.get(i);
            if (!st.isEmpty()) {
                int ix = x0 + 4 + i * 20;
                int iy = y0 + 4;
                mc.getItemRenderer().renderAndDecorateItem(st, ix, iy);
                mc.getItemRenderer().renderGuiItemDecorations(font, st, ix, iy);
            }
        }
        ItemStack off = p.getOffhandItem();
        if (!off.isEmpty()) {
            frame(ps, x0 - 28, y0, x0 - 4, y0 + 24);
            mc.getItemRenderer().renderAndDecorateItem(off, x0 - 24, y0 + 4);
            mc.getItemRenderer().renderGuiItemDecorations(font, off, x0 - 24, y0 + 4);
        }

        // ---- experiência ----
        bar(ps, x0, h - 46, 184, 3, p.experienceProgress, 0xFF9BF06A, 0xFF3FA02A, 0xFF10200C);
        if (p.experienceLevel > 0) {
            frame(ps, x0 - 24, h - 52, x0 - 4, h - 34);
            GuiComponent.drawCenteredString(ps, font, String.valueOf(p.experienceLevel), x0 - 14, h - 47, 0xFF9BF06A);
        }

        // ---- armadura (barra fina, só aparece com armadura) ----
        int armor = p.getArmorValue();
        if (armor > 0) {
            bar(ps, x0, h - 41, 90, 2, Math.min(1.0F, armor / 20.0F), 0xFFC6D6E8, 0xFF8095AA, 0xFF141A20);
        }

        // ---- vida ----
        float hp = p.getHealth();
        float max = p.getMaxHealth();
        int topC = 0xFFD03038;
        int botC = 0xFF7A1018;
        if (p.hasEffect(MobEffects.POISON)) {
            topC = 0xFF9AAA2A;
            botC = 0xFF55611A;
        } else if (p.hasEffect(MobEffects.WITHER)) {
            topC = 0xFF4A4A4A;
            botC = 0xFF1E1E1E;
        }
        bar(ps, x0, h - 37, 90, 9, max <= 0 ? 0 : hp / max, topC, botC, 0xFF2A0D0F);
        float absorb = p.getAbsorptionAmount();
        if (absorb > 0.0F) {
            fill(ps, x0, h - 37, x0 + Mth.clamp((int) (90 * absorb / max), 1, 90), h - 35, 0xFFFFD83A);
        }
        String hpText = (int) Math.ceil(hp) + "/" + (int) Math.ceil(max);
        font.drawShadow(ps, hpText, x0 + 45 - font.width(hpText) / 2.0F, h - 36, 0xFFFFFFFF);

        // ---- fome ----
        int fx = cx + 2;
        int food = p.getFoodData().getFoodLevel();
        bar(ps, fx, h - 37, 90, 9, food / 20.0F, 0xFFE8962A, 0xFF9A4F0A, 0xFF241208);
        float sat = p.getFoodData().getSaturationLevel();
        if (sat > 0.0F) {
            fill(ps, fx, h - 37, fx + Mth.clamp((int) (90 * sat / 20.0F), 1, 90), h - 35, 0xCCFFE29A);
        }
        String foodText = String.valueOf(food);
        font.drawShadow(ps, foodText, fx + 45 - font.width(foodText) / 2.0F, h - 36, 0xFFFFFFFF);

        // ---- ar (embaixo d'água) ----
        int air = p.getAirSupply();
        if (p.isEyeInFluid(FluidTags.WATER) || air < p.getMaxAirSupply()) {
            bar(ps, fx, h - 41, 90, 2, Mth.clamp(air / (float) p.getMaxAirSupply(), 0.0F, 1.0F),
                    0xFF8FE8FF, 0xFF2D9ACB, 0xFF0A1A24);
        }

        // ---- habilidade (tecla J) ----
        int race = ClientRace.get(p.getUUID());
        if (race != Race.NONE) {
            renderAbility(ps, font, race, x0 + 184 + 6, y0);
        }

        // ---- arranhão de garra (1ª pessoa) ----
        if (ClientRace.slash > 0 && mc.options.getCameraType().isFirstPerson()) {
            renderSlash(ps, w, h, 1.0F - ClientRace.slash / 8.0F);
        }
    }

    private static void renderAbility(PoseStack ps, Font font, int race, int x, int y) {
        boolean active = ClientRace.scentActive > 0;
        boolean cooling = !active && ClientRace.scentCooldown > 0;
        frame(ps, x, y, x + 24, y + 24);
        int tint = active ? 0x6655CCFF : (cooling ? 0x66A02020 : 0x6655CC55);
        fill(ps, x + 2, y + 2, x + 22, y + 22, tint);
        fill(ps, x + 2, y + 2, x + 8, y + 9, 0xAA000000);
        font.draw(ps, "J", x + 4, y + 2, GOLD_LIGHT);
        if (active) {
            String s = String.valueOf((int) Math.ceil(ClientRace.scentActive / 20.0D));
            GuiComponent.drawCenteredString(ps, font, s, x + 12, y + 9, 0xFFFFFFFF);
            bar(ps, x + 3, y + 19, 18, 2, ClientRace.scentActive / (float) Race.SCENT_ACTIVE_TICKS,
                    0xFF8FE8FF, 0xFF2D9ACB, 0xFF0A1A24);
        } else if (cooling) {
            String s = String.valueOf((int) Math.ceil(ClientRace.scentCooldown / 20.0D));
            GuiComponent.drawCenteredString(ps, font, s, x + 12, y + 9, 0xFFFF8888);
        } else {
            GuiComponent.drawCenteredString(ps, font, "OK", x + 12, y + 9, 0xFFAAFFAA);
        }
        GuiComponent.drawCenteredString(ps, font,
                new TranslatableComponent(race == Race.WOLF ? "ability.zootopiarpg.wolf" : "ability.zootopiarpg.dog"),
                x + 12, y - 10, GOLD_LIGHT);
    }

    /** Três riscos diagonais que "cortam" a tela e somem. */
    private static void renderSlash(PoseStack ps, int w, int h, float progress) {
        float alpha = 1.0F - progress * 0.8F;
        int color = ((int) (255 * alpha) << 24) | 0xFFEEDD;
        int steps = 44;
        int upto = Math.max(1, (int) (steps * Math.min(1.0F, progress * 2.0F)));
        for (int line = 0; line < 3; line++) {
            float ox = (line - 1) * 16.0F;
            float x1 = w / 2.0F + 70.0F + ox;
            float y1 = h / 2.0F - 70.0F;
            float x2 = w / 2.0F - 70.0F + ox;
            float y2 = h / 2.0F + 50.0F;
            for (int i = 0; i <= upto; i++) {
                float t = i / (float) steps;
                int px = (int) Mth.lerp(t, x1, x2);
                int py = (int) Mth.lerp(t, y1, y2);
                int size = 3 - (int) Math.abs((t - 0.5F) * 2.0F * 1.5F);
                fill(ps, px, py, px + Math.max(1, size), py + Math.max(1, size), color);
            }
        }
    }
}
