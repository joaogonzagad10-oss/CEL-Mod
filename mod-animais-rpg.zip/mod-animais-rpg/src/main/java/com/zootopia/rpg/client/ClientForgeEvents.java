package com.zootopia.rpg.client;

import com.zootopia.rpg.ZootopiaRPG;
import com.zootopia.rpg.common.Race;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RenderArmEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderLevelLastEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.client.gui.ForgeIngameGui;
import net.minecraftforge.client.gui.IIngameOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ZootopiaRPG.MODID, value = Dist.CLIENT)
public class ClientForgeEvents {

    private static boolean hasRace(Minecraft mc) {
        return mc.player != null && ClientRace.get(mc.player.getUUID()) != Race.NONE;
    }

    /** Troca a skin normal pelo corpo de cachorro/lobo. */
    @SubscribeEvent
    public static void onRenderPlayer(RenderPlayerEvent.Pre e) {
        if (!(e.getPlayer() instanceof AbstractClientPlayer p)) return;
        if (ClientRace.get(p.getUUID()) == Race.NONE) return;
        AnimalPlayerRenderer r = ClientModEvents.playerRenderer;
        if (r == null) return;
        e.setCanceled(true);
        r.render(p, 0.0F, e.getPartialTick(), e.getPoseStack(), e.getMultiBufferSource(), e.getPackedLight());
    }

    /** Mão peluda (com garras) em primeira pessoa. */
    @SubscribeEvent
    public static void onRenderArm(RenderArmEvent e) {
        AbstractClientPlayer p = e.getPlayer();
        if (ClientRace.get(p.getUUID()) == Race.NONE) return;
        AnimalPlayerRenderer r = ClientModEvents.playerRenderer;
        if (r == null) return;
        e.setCanceled(true);
        r.renderHand(e.getPoseStack(), e.getMultiBufferSource(), e.getPackedLight(), p,
                e.getArm() == HumanoidArm.RIGHT);
    }

    /** Nomes do farejar/ouvir, visíveis através de blocos. */
    @SubscribeEvent
    public static void onRenderLevelLast(RenderLevelLastEvent e) {
        ScentRenderer.render(e.getPoseStack(), e.getPartialTick());
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        int race = ClientRace.get(mc.player.getUUID());

        // a escolha é obrigatória: se a tela sumiu por qualquer motivo, abre de novo
        if (ClientRace.mustChoose && race == Race.NONE && mc.screen == null) {
            mc.setScreen(new RaceSelectScreen());
        }

        if (ClientRace.slash > 0) ClientRace.slash--;
        if (ClientRace.scentActive > 0) {
            if (--ClientRace.scentActive == 0) ClientRace.scentCooldown = Race.SCENT_COOLDOWN_TICKS;
        } else if (ClientRace.scentCooldown > 0) {
            ClientRace.scentCooldown--;
        }

        while (ClientModEvents.SCENT_KEY.consumeClick()) {
            if (race != Race.NONE && mc.screen == null
                    && ClientRace.scentActive == 0 && ClientRace.scentCooldown == 0) {
                ClientRace.scentActive = Race.SCENT_ACTIVE_TICKS;
                mc.player.playSound(race == Race.WOLF ? SoundEvents.WOLF_HOWL : SoundEvents.FOX_SNIFF, 0.8F, 1.0F);
            }
        }
        while (ClientModEvents.CAMERA_KEY.consumeClick()) {
            CameraType c = mc.options.getCameraType();
            mc.options.setCameraType(c == CameraType.FIRST_PERSON ? CameraType.THIRD_PERSON_BACK : CameraType.FIRST_PERSON);
        }
    }

    /** Começa a animação de arranhão na tela quando bate de mãos vazias. */
    @SubscribeEvent
    public static void onClick(InputEvent.ClickInputEvent e) {
        Minecraft mc = Minecraft.getInstance();
        if (e.isAttack() && hasRace(mc) && mc.screen == null && mc.player.getMainHandItem().isEmpty()) {
            ClientRace.slash = 8;
        }
    }

    /** Troca o HUD padrão pelo HUD de RPG (só depois de escolher a raça). */
    @SubscribeEvent
    public static void onPreLayer(RenderGameOverlayEvent.PreLayer e) {
        Minecraft mc = Minecraft.getInstance();
        if (!hasRace(mc)) return;
        IIngameOverlay o = e.getOverlay();
        if (o == ForgeIngameGui.HOTBAR_ELEMENT) {
            e.setCanceled(true);
            RpgHud.render(e.getMatrixStack(), e.getWindow().getGuiScaledWidth(), e.getWindow().getGuiScaledHeight());
        } else if (o == ForgeIngameGui.PLAYER_HEALTH_ELEMENT
                || o == ForgeIngameGui.FOOD_LEVEL_ELEMENT
                || o == ForgeIngameGui.ARMOR_LEVEL_ELEMENT
                || o == ForgeIngameGui.AIR_LEVEL_ELEMENT
                || o == ForgeIngameGui.EXPERIENCE_BAR_ELEMENT) {
            e.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggedOutEvent e) {
        ClientRace.clearAll();
    }
}
