package com.zootopia.rpg.common;

import com.zootopia.rpg.ZootopiaRPG;
import com.zootopia.rpg.client.ClientHooks;
import java.util.UUID;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class Net {
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(ZootopiaRPG.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private Net() {}

    public static void register() {
        int id = 0;
        CH.registerMessage(id++, ChooseRace.class, ChooseRace::encode, ChooseRace::decode, ChooseRace::handle);
        CH.registerMessage(id++, SyncRace.class, SyncRace::encode, SyncRace::decode, SyncRace::handle);
        CH.registerMessage(id++, OpenChoice.class, OpenChoice::encode, OpenChoice::decode, OpenChoice::handle);
    }

    /** Cliente -> servidor: jogador escolheu a raça. */
    public static class ChooseRace {
        public final int race;

        public ChooseRace(int race) {
            this.race = race;
        }

        public static void encode(ChooseRace m, FriendlyByteBuf b) {
            b.writeVarInt(m.race);
        }

        public static ChooseRace decode(FriendlyByteBuf b) {
            return new ChooseRace(b.readVarInt());
        }

        public static void handle(ChooseRace m, Supplier<NetworkEvent.Context> s) {
            NetworkEvent.Context c = s.get();
            c.enqueueWork(() -> {
                ServerPlayer p = c.getSender();
                if (p != null) ServerEvents.choose(p, m.race);
            });
            c.setPacketHandled(true);
        }
    }

    /** Servidor -> cliente: qual a raça de um jogador (para renderizar). */
    public static class SyncRace {
        public final UUID id;
        public final int race;

        public SyncRace(UUID id, int race) {
            this.id = id;
            this.race = race;
        }

        public static void encode(SyncRace m, FriendlyByteBuf b) {
            b.writeUUID(m.id);
            b.writeVarInt(m.race);
        }

        public static SyncRace decode(FriendlyByteBuf b) {
            return new SyncRace(b.readUUID(), b.readVarInt());
        }

        public static void handle(SyncRace m, Supplier<NetworkEvent.Context> s) {
            NetworkEvent.Context c = s.get();
            c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                    () -> () -> ClientHooks.setRace(m.id, m.race)));
            c.setPacketHandled(true);
        }
    }

    /** Servidor -> cliente: abrir a tela obrigatória de escolha. */
    public static class OpenChoice {
        public static void encode(OpenChoice m, FriendlyByteBuf b) {}

        public static OpenChoice decode(FriendlyByteBuf b) {
            return new OpenChoice();
        }

        public static void handle(OpenChoice m, Supplier<NetworkEvent.Context> s) {
            NetworkEvent.Context c = s.get();
            c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                    () -> ClientHooks::openChoice));
            c.setPacketHandled(true);
        }
    }
}
