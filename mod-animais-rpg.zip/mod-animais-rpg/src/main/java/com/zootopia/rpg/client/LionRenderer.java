package com.zootopia.rpg.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.zootopia.rpg.ZootopiaRPG;
import com.zootopia.rpg.entity.AbstractLion;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class LionRenderer extends MobRenderer<AbstractLion, LionModel> {
    private static final ResourceLocation GOOD = new ResourceLocation(ZootopiaRPG.MODID, "textures/entity/lion_good.png");
    private static final ResourceLocation EVIL = new ResourceLocation(ZootopiaRPG.MODID, "textures/entity/lion_evil.png");

    public LionRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new LionModel(ctx.bakeLayer(ClientModEvents.LION)), 0.9F);
    }

    @Override
    public ResourceLocation getTextureLocation(AbstractLion lion) {
        return lion.isEvil() ? EVIL : GOOD;
    }

    @Override
    protected void scale(AbstractLion lion, PoseStack ps, float partial) {
        ps.scale(1.25F, 1.25F, 1.25F);
    }
}
