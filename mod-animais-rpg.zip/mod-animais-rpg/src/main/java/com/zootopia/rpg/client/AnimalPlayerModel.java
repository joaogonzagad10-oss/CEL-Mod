package com.zootopia.rpg.client;

import com.zootopia.rpg.common.Race;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;

/**
 * Corpo bípede (2 patas, 2 mãos) estilo Zootopia: o corpo de jogador padrão com focinho, orelhas, rabo e garras.
 * Cachorro e lobo usam o mesmo modelo; partes específicas de cada um são ligadas/desligadas conforme a raça.
 *
 * Layout da textura (64x64):
 *  - cabeça (0,0), corpo (16,16), braços (40,16), pernas (0,16) — igual ao Minecraft antigo
 *  - focinho cachorro (0,32), focinho lobo (16,32), nariz (36,32), garras (40,32)
 *  - orelha cachorro (0,42), orelha lobo (10,42), rabo cachorro (20,42), rabo lobo (0,52)
 */
public class AnimalPlayerModel extends HumanoidModel<AbstractClientPlayer> {
    private final ModelPart snoutDog;
    private final ModelPart snoutWolf;
    private final ModelPart nose;
    private final ModelPart dogEarL;
    private final ModelPart dogEarR;
    private final ModelPart wolfEarL;
    private final ModelPart wolfEarR;
    private final ModelPart dogTail;
    private final ModelPart wolfTail;

    public AnimalPlayerModel(ModelPart root) {
        super(root);
        ModelPart head = root.getChild("head");
        ModelPart body = root.getChild("body");
        this.snoutDog = head.getChild("snout_dog");
        this.snoutWolf = head.getChild("snout_wolf");
        this.nose = head.getChild("nose");
        this.dogEarL = head.getChild("dog_ear_l");
        this.dogEarR = head.getChild("dog_ear_r");
        this.wolfEarL = head.getChild("wolf_ear_l");
        this.wolfEarR = head.getChild("wolf_ear_r");
        this.dogTail = body.getChild("dog_tail");
        this.wolfTail = body.getChild("wolf_tail");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = HumanoidModel.createMesh(CubeDeformation.NONE, 0.0F);
        PartDefinition root = mesh.getRoot();

        PartDefinition head = root.getChild("head");
        head.addOrReplaceChild("snout_dog", CubeListBuilder.create().texOffs(0, 32)
                .addBox(-2.0F, -3.0F, -7.0F, 4.0F, 3.0F, 3.0F), PartPose.ZERO);
        head.addOrReplaceChild("snout_wolf", CubeListBuilder.create().texOffs(16, 32)
                .addBox(-2.0F, -3.0F, -9.0F, 4.0F, 3.0F, 5.0F), PartPose.ZERO);
        head.addOrReplaceChild("nose", CubeListBuilder.create().texOffs(36, 32)
                .addBox(-1.0F, 0.0F, -1.0F, 2.0F, 1.0F, 1.0F), PartPose.offset(0.0F, -3.4F, -7.0F));

        // orelhas caídas do cachorro
        head.addOrReplaceChild("dog_ear_r", CubeListBuilder.create().texOffs(0, 42)
                .addBox(-1.0F, 0.0F, -1.5F, 1.0F, 4.0F, 3.0F),
                PartPose.offsetAndRotation(-4.0F, -7.0F, 0.0F, 0.0F, 0.0F, 0.25F));
        head.addOrReplaceChild("dog_ear_l", CubeListBuilder.create().texOffs(0, 42).mirror()
                .addBox(0.0F, 0.0F, -1.5F, 1.0F, 4.0F, 3.0F),
                PartPose.offsetAndRotation(4.0F, -7.0F, 0.0F, 0.0F, 0.0F, -0.25F));
        // orelhas em pé do lobo
        head.addOrReplaceChild("wolf_ear_r", CubeListBuilder.create().texOffs(10, 42)
                .addBox(-1.5F, -3.0F, -0.5F, 3.0F, 3.0F, 1.0F),
                PartPose.offsetAndRotation(-2.8F, -8.0F, 0.5F, 0.0F, 0.0F, -0.15F));
        head.addOrReplaceChild("wolf_ear_l", CubeListBuilder.create().texOffs(10, 42).mirror()
                .addBox(-1.5F, -3.0F, -0.5F, 3.0F, 3.0F, 1.0F),
                PartPose.offsetAndRotation(2.8F, -8.0F, 0.5F, 0.0F, 0.0F, 0.15F));

        PartDefinition body = root.getChild("body");
        body.addOrReplaceChild("dog_tail", CubeListBuilder.create().texOffs(20, 42)
                .addBox(-1.0F, -1.0F, 0.0F, 2.0F, 2.0F, 6.0F),
                PartPose.offsetAndRotation(0.0F, 10.5F, 2.0F, 0.9F, 0.0F, 0.0F));
        body.addOrReplaceChild("wolf_tail", CubeListBuilder.create().texOffs(0, 52)
                .addBox(-1.5F, -1.5F, 0.0F, 3.0F, 3.0F, 7.0F),
                PartPose.offsetAndRotation(0.0F, 10.5F, 2.0F, -0.55F, 0.0F, 0.0F));

        // garras nas duas mãos
        PartDefinition rightArm = root.getChild("right_arm");
        PartDefinition leftArm = root.getChild("left_arm");
        for (int i = 0; i < 3; i++) {
            float x = -2.6F + i * 1.3F;
            rightArm.addOrReplaceChild("claw" + i, CubeListBuilder.create().texOffs(40, 32)
                    .addBox(x, 10.0F, -1.5F, 1.0F, 2.0F, 1.0F), PartPose.ZERO);
            leftArm.addOrReplaceChild("claw" + i, CubeListBuilder.create().texOffs(40, 32)
                    .addBox(-0.6F + i * 1.3F, 10.0F, -1.5F, 1.0F, 2.0F, 1.0F), PartPose.ZERO);
        }

        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(AbstractClientPlayer p, float limbSwing, float limbSwingAmount, float age,
                          float netHeadYaw, float headPitch) {
        super.setupAnim(p, limbSwing, limbSwingAmount, age, netHeadYaw, headPitch);

        boolean wolf = ClientRace.get(p.getUUID()) == Race.WOLF;
        this.hat.visible = false;
        this.snoutDog.visible = !wolf;
        this.dogEarL.visible = !wolf;
        this.dogEarR.visible = !wolf;
        this.dogTail.visible = !wolf;
        this.snoutWolf.visible = wolf;
        this.wolfEarL.visible = wolf;
        this.wolfEarR.visible = wolf;
        this.wolfTail.visible = wolf;
        this.nose.setPos(0.0F, -3.4F, wolf ? -9.0F : -7.0F);

        // rabo: cachorro balança rápido, lobo balança devagar
        float wag = wolf ? Mth.sin(age * 0.08F) * 0.18F : Mth.sin(age * 0.45F) * 0.45F;
        this.dogTail.yRot = wag;
        this.wolfTail.yRot = wag;
        float run = Math.min(limbSwingAmount, 1.0F);
        this.dogTail.xRot = 0.9F - run * 0.2F;
        this.wolfTail.xRot = -0.55F + run * 0.35F;
        if (this.crouching) {
            this.dogTail.y = 8.0F;
            this.wolfTail.y = 8.0F;
        } else {
            this.dogTail.y = 10.5F;
            this.wolfTail.y = 10.5F;
        }

        // golpe de garra: de mãos vazias a pata faz um arranhão diagonal
        if (this.attackTime > 0.0F && p.getMainHandItem().isEmpty()) {
            ModelPart arm = p.getMainArm() == HumanoidArm.RIGHT ? this.rightArm : this.leftArm;
            float t = this.attackTime;
            arm.xRot = -2.0F + t * 1.5F;
            arm.zRot = (p.getMainArm() == HumanoidArm.RIGHT ? 1.0F : -1.0F) * (0.9F - t * 1.8F);
            arm.yRot = 0.0F;
        }
    }
}
