package com.zootopia.rpg.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

/** Leão do bem: guarda o portão e as portas do castelo preto e cinza. */
public class GoodLion extends AbstractLion {
    public GoodLion(EntityType<? extends GoodLion> type, Level level) {
        super(type, level);
    }

    @Override
    public boolean isEvil() {
        return false;
    }
}
