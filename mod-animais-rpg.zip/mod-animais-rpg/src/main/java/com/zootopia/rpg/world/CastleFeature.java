package com.zootopia.rpg.world;

import com.zootopia.rpg.ModStructures;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.StructureFeature;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.PieceGenerator;
import net.minecraft.world.level.levelgen.structure.PieceGeneratorSupplier;

/** Estrutura de castelo. evil=false: castelo preto e cinza (leões do bem); evil=true: castelo sombrio. */
public class CastleFeature extends StructureFeature<NoneFeatureConfiguration> {

    public CastleFeature(boolean evil) {
        super(NoneFeatureConfiguration.CODEC, ctx -> create(ctx, evil));
    }

    private static Optional<PieceGenerator<NoneFeatureConfiguration>> create(
            PieceGeneratorSupplier.Context<NoneFeatureConfiguration> ctx, boolean evil) {
        if (!ctx.validBiomeOnTop(Heightmap.Types.WORLD_SURFACE_WG)) return Optional.empty();

        int size = evil ? CastlePiece.EVIL_SIZE : CastlePiece.GOOD_SIZE;
        ChunkPos cp = ctx.chunkPos();
        int x0 = cp.getMiddleBlockX() - size / 2;
        int z0 = cp.getMiddleBlockZ() - size / 2;

        // amostra o terreno em 9 pontos para achar o nível do chão
        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;
        long sum = 0;
        int n = 0;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                int x = x0 + i * (size - 1) / 2;
                int z = z0 + j * (size - 1) / 2;
                int h = ctx.chunkGenerator().getBaseHeight(x, z, Heightmap.Types.WORLD_SURFACE_WG, ctx.heightAccessor());
                min = Math.min(min, h);
                max = Math.max(max, h);
                sum += h;
                n++;
            }
        }
        // sem oceano nem terreno muito acidentado
        if (min <= 62 || max - min > 9) return Optional.empty();
        int ground = (int) (sum / n);

        final int fx = x0;
        final int fz = z0;
        return Optional.of((builder, context) -> {
            BoundingBox bb = new BoundingBox(fx, ground, fz, fx + size - 1, ground + 40, fz + size - 1);
            builder.addPiece(new CastlePiece(ModStructures.CASTLE_PIECE, bb, evil));
        });
    }
}
